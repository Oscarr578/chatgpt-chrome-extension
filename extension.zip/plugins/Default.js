export default {
  rules: [
    `If I say create something I mean do some creative writing about it, not browse the internet.`,
  ],
};
